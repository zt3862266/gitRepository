<div id="footer"><p>
<?php bloginfo('name'); ?> is powered by <a href="http://wordpress.org/">WordPress</a><br/>
Theme by <a href="http://stua.rtbrown.org">Stuart Brown</a> / <a href="http://www.modernlifeisrubbish.co.uk">Modern Life</a>
</p></div></div><?php wp_footer(); ?></body></html>
